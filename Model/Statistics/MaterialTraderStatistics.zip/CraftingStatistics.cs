namespace EliteHelper.Statistics
{
    public classCrafting 
    {
        public long Count_Of_Used_Engineers { get; set; }
        public long Recipes_Generated { get; set; }
        public long Recipes_Generated_Rank_1 { get; set; }
        public long Recipes_Generated_Rank_2 { get; set; }
        public long Recipes_Generated_Rank_3 { get; set; }
        public long Recipes_Generated_Rank_4 { get; set; }
        public long Recipes_Generated_Rank_5 { get; set; }
    }
}