namespace EliteHelper.Statistics
{
    public class Passengers 
    {
        public long Passengers_Missions_Accepted { get; set; }
        public long Passengers_Missions_Disgruntled { get; set; }
        public long Passengers_Missions_Bulk { get; set; }
        public long Passengers_Missions_VIP { get; set; }
        public long Passengers_Missions_Delivered { get; set; }
        public long Passengers_Missions_Ejected { get; set; }
    }
}