namespace EliteHelper.Statistics
{
    public class Mining 
    {
        public long Mining_Profits { get; set; }
        public long Quantity_Mined { get; set; }
        public long Materials_Collected { get; set; }
    }
}