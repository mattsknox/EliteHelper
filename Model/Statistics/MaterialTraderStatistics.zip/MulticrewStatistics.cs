namespace EliteHelper.Statistics
{
    public class Multicrew 
    {
        public long Multicrew_Time_Total { get; set; }
        public long Multicrew_Gunner_Time_Total { get; set; }
        public long Multicrew_Fighter_Time_Total { get; set; }
        public long Multicrew_Credits_Total { get; set; }
        public long Multicrew_Fines_Total { get; set; }
    }
}