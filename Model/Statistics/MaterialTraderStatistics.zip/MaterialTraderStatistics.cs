namespace EliteHelper.Statistics
{
    public class MaterialTrader 
    {
        public long Trades_Completed { get; set; }
        public long Materials_Traded { get; set; }
    }
}