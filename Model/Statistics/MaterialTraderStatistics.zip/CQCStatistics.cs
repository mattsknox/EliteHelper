namespace EliteHelper.Statistics
{
    public classCQC 
    {
        public long CQC_Credits_Earned { get; set; }
        public long CQC_Time_Played { get; set; }
        public long CQC_KD { get; set; }
        public long CQC_Kills { get; set; }
        public long CQC_WL { get; set; }
    }
}