namespace EliteHelper.Statistics
{
    public class Smuggling 
    {
        public long Black_Markets_Traded_With { get; set; }
        public long Black_Markets_Profits { get; set; }
        public long Resources_Smuggled { get; set; }
        public long Average_Profit { get; set; }
        public long Highest_Single_Transaction { get; set; }
    }
}