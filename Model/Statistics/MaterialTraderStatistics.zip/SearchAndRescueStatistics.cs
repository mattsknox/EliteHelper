namespace EliteHelper.Statistics
{
    public class SearchAndRescue 
    {
        public long SearchRescue_Traded { get; set; }
        public long SearchRescue_Profit { get; set; }
        public long SearchRescue_Count { get; set; }
    }
}