namespace EliteHelper.Statistics
{
    public classCrew 
    {
        public long NpcCrew_TotalWages { get; set; }
        public long NpcCrew_Hired { get; set; }
        public long NpcCrew_Fired { get; set; }
    }
}