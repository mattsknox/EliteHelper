namespace EliteHelper.Statistics
{
    public classCombat
    {
        public long MyProperty { get; set; }
        public long Bounties_Claimed { get; set; }
        public long Bounty_Hunting_Profit { get; set; }
        public long Combat_Bonds { get; set; }
        public long Combat_Bond_Profits { get; set; }
        public long Assassinations { get; set; }
        public long Assassination_Profits { get; set; }
        public long Highest_Single_Reward { get; set; }
        public long Skimmers_Killed { get; set; }
    }
}