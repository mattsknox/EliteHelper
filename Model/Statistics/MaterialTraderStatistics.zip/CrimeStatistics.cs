namespace EliteHelper.Statistics
{
    public class Crime
    {
        public long Notoriety { get; set; }
        public long Fines { get; set; }
        public long Total_Fines { get; set; }
        public long Bounties_Received { get; set; }
        public long Total_Bounties { get; set; }
        public long Highest_Bounty { get; set; }
    }
}